#module1.py

print(f'loading module1.py: __name__ = {__name__}')

if __name__ == '__main__':
    print('Module was executed')